# Figures for Chapters 3–5

Nine diagrams, supplied as SVG (vector, for print) and PNG (raster, for Notion or Word).
Each replaces the corresponding placeholder callout in the manuscript.

| File | Replaces | Section |
|---|---|---|
| figure-3-1-testbed-topology | Figure 3.1 | 3.1 Testbed Topology |
| figure-3-2-cockroachdb-query-path | Figure 3.2 | 3.3 How a Query Travels: CockroachDB |
| figure-3-3-postgresql-patroni-query-path | Figure 3.3 | 3.4 How a Query Travels: PostgreSQL under Patroni |
| figure-3-4-fault-and-measurement-paths | Figure 3.4 | 3.5 How a Fault Travels |
| figure-4-1-orchestration-flow | Figure 4.1 | 4.1 Orchestration: Four Phases |
| figure-4-2-fault-timeline | Figure 4.2 | 4.4 Fault Injection Parameters |
| figure-5-1-write-quorum-geometry | Figure 5.1 | 5.2 Pinning Write-Quorum Geometry |
| figure-5-2-single-measurement-path | Figure 5.2 | 5.3 One Measurement Path for Both Engines |
| figure-5-3-run-directory-structure | Figure 5.3 | 5.4 Run Artefact Discipline |

Still outstanding, and not in this set:
- Figures 6.1 and 6.2 — export charts A1 and B6 from the existing catalogue.
- The D4 and D5 charts already embedded in section 6.4 need numbering as Figures 6.7 and 6.8, with captions and in-text citations.

## Palette

Matched to the existing result charts: CockroachDB #1F77B4, PostgreSQL/Patroni #FF7F0E,
faults #C0392B, infrastructure belonging to neither engine in neutral grey, background #F7F7F7.
Colour never carries meaning alone, so the set survives greyscale printing.

## Two things to check before these are final

1. Figure 3.3 omits the distributed configuration store. Which DCS is deployed, and where it runs,
   could not be confirmed from the project files, and a generic etcd box would be a guess.
2. Figure 4.1 shows Phase III and Phase IV as separate phases, following the manuscript. The run IDs
   in Chapter 6 are all suffixed `_p4-chaos-dead` or `_p4-chaos-recover`, and data-schema.md records
   `p4_chaos` as one phase covering both modes. If that is right, both this figure and Chapter 4's
   prose need adjusting.
